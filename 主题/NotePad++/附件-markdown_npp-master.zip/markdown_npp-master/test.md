# Headings (\# \#\# \#\#\# etc.)

Alt Heading 1 (Headings need 4 = or -)
====

Alt Heading 2 (Headings need 4 = or -)
----

Normal text **bold** then *italic*.
Escape \* \` \< \_ \# \\ & more.

1. Order list
- Unorder list ( - or + )

code: `a === a`

> blockquote

URL: [Edditoria][1] | image: ![2][]

[1]: https://edditoria.blogspot.com
[2]: https://avatars0.githubusercontent.com/u/2234073?v=3&s=40

<!-- please comment -->

# Enjoy! :)



